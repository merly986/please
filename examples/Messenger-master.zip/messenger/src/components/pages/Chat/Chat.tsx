import React, {Dispatch, FC, SetStateAction, useEffect, useState} from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import {ChatroomList} from "@src/components/ChatroomList/ChatroomList";
import {UserList} from "@src/components/UserList/UserList";
import {Chatroom} from "@src/components/Chatroom/Chatroom";
import {ChatContext} from "@src/ChatroomContext";
import {IJson} from "@src/interfaces/IJson";
import {whoAmI} from "@src/controllers/WhoAmI";
import {IUser} from "@src/interfaces/IUser";
import {IChatroom} from "@src/interfaces/IChatroom";
import {IMessage} from "@src/interfaces/IMessage";
import {getChatrooms, getLastChatroomUUID} from "@src/controllers/Chatrooms";
import {getMessages} from "@src/controllers/Messages";
import "./ChatStyle.css";
import {Simulate} from "react-dom/test-utils";
import toggle = Simulate.toggle;
import {IconButton} from "@mui/material";

function showUsers(state: boolean, setState: Dispatch<SetStateAction<boolean>>) {
    setState(!state);
}

export const Chat: FC = () => {
    const [currentUser, setCurrentUser] = useState<IUser>(undefined);
    const [chatroom, setChatroom] = useState<IChatroom>(undefined);
    const [chatrooms, setChatrooms] = useState<IChatroom[]>(undefined);
    const [users, setUsers] = useState<IUser[]>([]);
    const [messages, setMessages] = useState<IMessage[]>([]);
    const [timerID, setTimerID] = useState<number>()
    const [updateAll, setUpdateAll] = useState(Math.random());

    const contextValue = {currentUser, chatroom, chatrooms, messages, users, setChatroom, setMessages, updateAll: () => setUpdateAll(Math.random()),};

    // Получаем текущего польлзователя
    useEffect(() => {
        async function run() {
            const json: IJson<IUser> = await whoAmI();

            if (json.error === 0) {
                if (json.result) setCurrentUser(json.result);
            } else {
                setCurrentUser(undefined);
                console.log(json.error);
            }
        }
        run();
    }, []);

    // Получаем chatroom'ы
    useEffect(() => {
        async function run() {
            const json: IJson<IChatroom[]> = await getChatrooms();

            if (json.error === 0) {
                setChatrooms(json.result);
            } else {
                setChatrooms(undefined);
                console.log(json.error);
            }

            if (timerID) clearInterval(timerID);
        }

        run();

        // Проверка новых сообщений (временно)
        setTimerID(Number(setInterval(run, 300000)));
    }, [updateAll]);

    // Если chatroom НЕ выбран, то выбераем первый.
    useEffect(() => {
        if (chatrooms) {
            const lastChatroomUUID = getLastChatroomUUID();
            setChatroom((lastChatroomUUID && chatrooms) ? chatrooms.filter(chatroom => chatroom.chatroom_uuid === lastChatroomUUID)[0] : undefined);
        }
    }, [chatrooms]);

    // Получаем сообщения из chatroom'а
    useEffect(() => {
        async function run() {
            const json: IJson<IMessage[]> = await getMessages(chatroom?.chatroom_uuid);

            if (json.error === 0) {
                setMessages(json.result);
            } else {
                setMessages(undefined);
                console.log(json.error);
            }
        }
        if (chatroom) {
            run();
        }
    }, [chatroom]);

    // Получаем плользователей из chatroom'а
    useEffect(() => {
        if (chatroom && currentUser) setUsers(chatroom.chatroom_users.filter((user) => user.rus_id !== currentUser.rus_id));
        else setUsers(undefined);
    }, [chatroom]);

    return (
        <>
            <div key="background"
                 className="position-absolute h-100 w-100 p-2 bg-body-secondary d-flex justify-content-center chat">
                <div key="main-background"
                     className="hstack position-relative h-100 w-100 rounded-4 shadow-sm"
                     style={{minWidth: 1174, maxWidth: 1500}}>
                    <ChatContext.Provider value={contextValue}>
                        <div key="chatroom-list" className="h-100 w-25 rounded-start-4 bg-white"
                             style={{minWidth: 300, maxWidth: 400}}>
                            <ChatroomList/>
                        </div>
                        <div key="current-chanroom" className="h-100 w-100" style={{minWidth: 624}}>
                            <Chatroom/>
                        </div>
                        <div key="user-list" className="users">
                            <UserList />
                        </div>
                    </ChatContext.Provider>
                </div>
            </div>
        </>
    );
};