import React, {
    ChangeEvent,
    JSX,
    useContext,
    useEffect,
    useState
} from "react";
import {UserCard} from "@src/components/UserList/UserCard/UserCard";
import {Button, Divider, IconButton, InputBase, Modal, TextField} from "@mui/material";
import {ChatContext} from "@src/ChatroomContext";
import "./UserList.css";
import ReactInputMask from "react-input-mask";
import {addUserToChatroom} from "@src/controllers/Chatrooms";
import {IJson} from "@src/interfaces/IJson";
import {IUser} from "@src/interfaces/IUser";

interface IPropsAddUserModal {
    addUser: Function,
    dropWindow: Function,
    updateUserList: Function,
}

/**
 * Модалка добавить пользователя в chatroom
 * @param props.addUser Функция добавления пользователя
 * @param props.dropWindow Функция закрытия окна
 * @param props.updateUserList Функция обновления списка пользователей
 * @constructor
 */
const AddUserModal = (props: IPropsAddUserModal): JSX.Element => {
    const {addUser, dropWindow, updateUserList} = props;

    const [title, setTitle] = useState(<div>Добавить пользователя</div>);
    const [disabled, setDisabled] = useState(false);
    const [isValueValid, setIsValueValid] = useState(false);

    let userIDValue: number = undefined;

    // Обработчик изменений в поле ввода userID
    function handleUserIDOnChange(event: ChangeEvent<HTMLInputElement>): void {
        const value: number = Number(event.target.value);
        if(value > 0) {
            userIDValue = value;
            setIsValueValid(true);
        }
        else {
            userIDValue = undefined;
            setIsValueValid(false);
        }
    }

    // Обработчик клика по кнопке "ДОБАВИТЬ"
    async function handleAddButtonOnClick() {
        const json: IJson<IUser> = await addUser(userIDValue);
        if (json.error === 0) {
            updateUserList();
            dropWindow();
        }
        else {
            setTitle(<div style={{color: "darkred"}}>{json.error}</div>);
            setDisabled(true);
        }
    }

    return (
        <>
            <Modal open onClose={() => dropWindow()} style={{
                position: 'absolute',
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
            }}>
                <div style={{
                    width: 300,
                    backgroundColor: "white",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    borderRadius: 12,
                    padding: 8,
                    gap: 8,
                }}>
                    <div style={{height: 50, width: "100%", display: "flex"}}>
                        <div style={{fontSize: 18, fontWeight: "bold", display: "flex",  alignItems: "end"}}>{title}</div>
                        <IconButton sx={{padding: 0, alignItems: "start", marginLeft: "auto", height: 24, width: 24}} onClick={dropWindow}>
                            <i className="fa-regular fa-circle-xmark"></i>
                        </IconButton>
                    </div>
                    <div className="d-flex flex-row w-100 gap-2">
                        <ReactInputMask mask="9999999999" maskChar="" onChange={handleUserIDOnChange} disabled={disabled}>
                            {() => <TextField size="small" placeholder="ID пользователя" disabled={disabled} error={!isValueValid}/>}
                        </ReactInputMask>
                        <Button variant="contained" onClick={handleAddButtonOnClick} hidden={disabled} disabled={!isValueValid}>Добавить</Button>
                        <Button variant="contained" color="error" onClick={() => dropWindow()} hidden={!disabled} disabled={!disabled}>Закрыть</Button>
                    </div>
                </div>
            </Modal>
        </>
    );
}

/**
 * Компонент 'Список пользователей'
 */
export const UserList = () => {
    const {chatroom, currentUser, users, updateAll} = useContext(ChatContext); // Получаем контекст
    const [searchValue, setSearchValue] = useState('');
    const [usersCard, setUsersCard] = useState<JSX.Element[]>([])
    const [modalAddUser, setModalAddUser] = useState(<></>);

    function handleAddUserButtonOnClick() {
        setModalAddUser(
            <AddUserModal dropWindow={() => setModalAddUser(<></>)}
                          addUser={(id: number) => addUserToChatroom(chatroom.chatroom_uuid, id)}
                          updateUserList={updateAll} />
        );
    }

    // Формируем спимок пользователей
    useEffect(() => {
        setUsersCard(users?.map((user) => <UserCard key={`user_${user?.rus_id}`} user={user}/>));
    }, [users]);

    return (
        <>
            <div className="user-list">
                <div className="user-list-header">
                    <div className="user-list-header-title">Пользователи</div>
                    {/*<IconButton className="bg-body-secondary me-2" style={{height: 40, width: 40}}>*/}
                    <div className="user-list-header-icon">
                        <i className="fa-solid fa-users"></i>
                    </div>
                    {/*</IconButton>*/}
                </div>

                <div key="users-list-search" className="hstack mx-2">
                    <div className="hstack border border-dark-subtle rounded-pill" style={{height: 40}}>
                        <InputBase className="ms-2" placeholder="Найти пользователя" title="Найти пользователя" disabled={users?.length === 0 || users === undefined} />
                        <Divider orientation="vertical" />
                        <IconButton style={{height: 36, width: 36, margin: 2}} disabled={!searchValue}>
                            <i className="fa-solid fa-magnifying-glass"></i>
                        </IconButton>
                    </div>
                    <IconButton style={{height: 36, width: 36, margin: 2}}
                                title="Добавить пользователя"
                                onClick={handleAddUserButtonOnClick}
                                hidden={chatroom?.creator_info?.rus_id !== currentUser?.rus_id}
                    >
                        <i className="fa-solid fa-user-plus"></i>
                    </IconButton>
                </div>

                <div key="user-card-list" className="user-card-list">
                    {usersCard ? usersCard.map(userCard => userCard) : <></>}
                </div>
            </div>
            {modalAddUser}
        </>
    );
};