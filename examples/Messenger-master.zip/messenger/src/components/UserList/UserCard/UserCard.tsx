import React from "react";
import {IUser} from "@src/interfaces/IUser";

interface IProps {
    user: IUser,
}

export const UserCard = (props: IProps) => {
    const {user} = props;
    // const avatarColor = Math.floor(Math.abs(Math.random()*16777215-13421772)).toString(16).padEnd(6, '0');
    // const avatarColor = Math.floor(Math.abs(Math.random()*16777215-8355711)).toString(16).padEnd(6, '0');

    if (user) {
        return (
            <>
                <div className="hstack gap-2 align-items-center ms-2" style={{minHeight: 50, cursor: "pointer"}}>
                    <div
                        className="text-white rounded-pill d-flex align-items-center justify-content-center fw-bold"
                        style={{
                            minHeight: 40,
                            minWidth: 40,
                            // backgroundColor: `#${avatarColor}`
                            backgroundColor: "#025EA1"
                        }}>{user?.rus_surname?.toUpperCase()[0]}{user?.rus_name?.toUpperCase()[0]}</div>
                    <div className="h-100 w-100 border-bottom border-dark-subtle d-flex align-items-center">
                        {user?.rus_surname[0].toUpperCase() + user?.rus_surname.slice(1).toLowerCase()} {user?.rus_name[0].toUpperCase()}.{user?.rus_patronymic[0].toUpperCase()}.
                    </div>
                </div>
            </>
        );
    } else return (<div className="border-bottom border-dark-subtle mx-2" style={{minHeight: 50}}></div>)
};