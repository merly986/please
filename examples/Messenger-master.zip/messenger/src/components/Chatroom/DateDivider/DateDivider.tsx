import React from "react";
import "./DateDivider.css";

export const DateDivider = ({children}) => {
    return (
        <>
            <div className="divider-date"><div className="date">{children}</div></div>
        </>
    );
};