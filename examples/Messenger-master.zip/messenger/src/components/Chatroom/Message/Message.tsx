import React from "react";
import "./Message.css";
import {IUser} from "@src/interfaces/IUser";
import {IMessage} from "@src/interfaces/IMessage";
import {timestampStringToFormatString} from "@src/controllers/Messages";

interface IProps {
    currentUser: IUser,
    message: IMessage
}

export const Message = (props: IProps) => {
    const {currentUser, message} = props;
    const side = {
        justifyContent: "start"
    };

    let messageType = <>
        <div className="d-flex align-items-end" style={side}>
            <svg viewBox="0 0 16 16" width="16" height="16">
                <rect width="100%" height="100%" fill="white" />
                <circle cx="0" cy="0" r="100%" fill="#efefef" />
            </svg>
            <div style={{maxWidth: "85%"}}>
                <div className="message-cloud-right">
                    <div key="message-cloud-header"
                         className="fw-bold fst-italic w-100 rounded-top-4 px-3 d-flex justify-content-start">
                        {message?.author_info?.full_name}
                    </div>
                    <div key="message-cloud-content" className="px-3">
                        <div style={{whiteSpace: "pre-wrap"}}>{message?.message_text}</div>
                        {/*<div style={{whiteSpace: "pre-wrap"}}><a href={message?.message_text} download target="_blank">{message?.message_text}</a></div>*/}
                        <div className="" style={{fontSize: 14, fontWeight: "bold", fontStyle: "italic", opacity: "50%"}}>
                            {timestampStringToFormatString(message?.post_created, "time")}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </>

    if(message?.author_info?.rus_id === currentUser?.rus_id) {
        messageType = <>
            <div className="d-flex align-items-end" style={{justifyContent: "end"}}>
                <div style={{maxWidth: "85%"}}>
                    <div className="message-cloud-left">
                        <div key="message-cloud-header" className="fw-bold fst-italic w-100 rounded-top-4 px-3 d-flex justify-content-end">
                            {message?.author_info?.full_name}
                        </div>
                        <div key="message-cloud-content" className="px-3">
                            <div style={{whiteSpace: "pre-wrap"}}>{message?.message_text}</div>
                            <div className="d-flex justify-content-end" style={{fontSize: 14, fontWeight: "bold", fontStyle: "italic", opacity: "75%"}}>
                                {timestampStringToFormatString(message?.post_created, "time")}
                            </div>
                        </div>
                    </div>
                </div>
                <svg viewBox="0 0 16 16" width="16" height="16">
                    <rect width="100%" height="100%" fill="rgba(2, 94, 161, 0.1)" />
                    <circle cx="100%" cy="0" r="100%" fill="#efefef" />
                </svg>
            </div>
        </>
    }

    return (
        <>
            {messageType}
        </>
    );
};