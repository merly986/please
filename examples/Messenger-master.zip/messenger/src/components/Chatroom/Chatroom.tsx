import React, {
    ChangeEvent, Dispatch, JSX,
    RefObject, SetStateAction,
    useContext,
    useEffect,
    useRef,
    useState
} from "react";
import {Message} from "@src/components/Chatroom/Message/Message";
import {IconButton} from "@mui/material";
import "./Chatroom.css";
import {ChatContext} from "@src/ChatroomContext";
import {IMessage} from "@src/interfaces/IMessage";
import {sendMessage, timestampStringToFormatString} from "@src/controllers/Messages";
import {IUser} from "@src/interfaces/IUser";
import {DateDivider} from "@src/components/Chatroom/DateDivider/DateDivider";

function createMessageList(messageList: IMessage[], unread_messages: number, currentUser: IUser): JSX.Element[] {
    const list: Array<JSX.Element> = [];
    const dividerIndex = messageList ? messageList.length - unread_messages : undefined;

    let messageDate = timestampStringToFormatString(messageList[0]?.post_created, "date")
    list.push(<DateDivider key={`divider-date_${messageDate}`}>{messageDate}</DateDivider>)

    for (let i = 0; i < messageList.length; i++) {

        if (timestampStringToFormatString(messageList[i].post_created, "date") !== messageDate) {
            messageDate = timestampStringToFormatString(messageList[i]?.post_created, "date")
            list.push(<DateDivider key={`divider-date_${messageDate}`}>{messageDate}</DateDivider>)

        }

        if (i === dividerIndex) {
            list.push(<div className="chatroom-message-list-divider">::: Новые сообщения :::</div>);
            list.push(<Message key={`message_${messageList[i]?.id}`} message={messageList[i]} currentUser={currentUser}/>);
        } else list.push(<Message key={`message_${messageList[i]?.id}`} message={messageList[i]} currentUser={currentUser}/>);
    }

    return list;
}

export const Chatroom = () => {
    const {currentUser, chatroom, messages, setMessages} = useContext(ChatContext);
    const [inputHeight, setInputHeight] = useState<number>(42);
    const [isMessageInputBlockDisabled, setIsMessageInputBlockDisabled] = useState(true);
    const [messageText, setMessageText] = useState('');

    const refMessageList: RefObject<HTMLDivElement> = useRef(); // Ссылка на список сообщений. Необходим для скрола сообщений
    const refMessageList2: RefObject<HTMLDivElement> = useRef(); // Ссылка на список сообщений. Необходим для скрола сообщений

    function handleMessageListOnScroll() {
        if (refMessageList.current.scrollTop === refMessageList.current.scrollHeight - refMessageList.current.clientHeight) {
            console.log('Scroll End')
            refMessageList.current.scrollTop = refMessageList.current.scrollTop - 1;
        }
    }


    // Обработчик ввода сообщения
    function handleTextAreaOnChange(event: ChangeEvent<HTMLTextAreaElement>) {
        if (event.target.value === '\n') return;
        else {
            const value = event.target.value;
            setMessageText(value);
        }
    }

    // Обработчик нажатия ENTER в поле ввода сообщения
    async function handleTextAreaOnKeyPress(event: any): Promise<void> {
        if (event.code === "Enter" && !event.shiftKey && messageText) await handleSendButtonOnClick();
    }

    // Обработчик нажатия кнопки отправить сообщение
    async function handleSendButtonOnClick(): Promise<void> {
        const message: IMessage = {
            chatroom: chatroom.id,
            message_text: messageText,
        }

        const json = await sendMessage(message);

        if (json.error === 0) {
            setMessages([...messages, json.result]);
        }
        setMessageText('');
    }

    //
    useEffect(() => {
        if (chatroom) setIsMessageInputBlockDisabled(false);
        else setIsMessageInputBlockDisabled(true);

        // Очищаем поле ввода сообщения при переходе между chatroom
        setMessageText('')
    }, [chatroom]);

    // Scroll чата к последнему сообщению
    useEffect(() => {
        refMessageList.current.scrollTop = refMessageList.current.scrollHeight - refMessageList.current.clientHeight - 1;
    }, [messages]);

    return (
        <>
            <div key="chatroom" className="chatroom">
                <div key="chatroom-name"
                     className="position-relative border-bottom border-dark-subtle d-flex justify-content-center align-items-center fw-bold h3 bg-white"
                     style={{minHeight: 58}}>
                    {chatroom?.chatroom_name}
                </div>
                <div key="message-list" className="chatroom-message-list" ref={refMessageList} onScroll={handleMessageListOnScroll}>
                    {/*<div key="spacer" className="border-top border-dark-subtle"></div>*/}
                    <div key="messages" className="messages" ref={refMessageList2}>
                        {/*{messages?.map((message) => <Message key={`message_${message?.id}`} message={message} currentUser={currentUser}/>)}*/}
                        {createMessageList(messages, chatroom?.unread_messages, currentUser)}
                    </div>
                </div>
                <div key="message-input" className="chatroom-message-input">
                    <div className="chatroom-message-input-tail">
                        <div className="chatroom-message-input-container">
                            <textarea className="chatroom-message-input-textarea"
                                      // rows={rows}
                                      value={messageText}
                                      placeholder="Сообщение"
                                      onFocus={() => setInputHeight(92)}
                                      onBlur={() => setTimeout(() => setInputHeight(42), 200)}
                                      onChange={(event) => handleTextAreaOnChange(event)}
                                      onKeyPress={(event) => handleTextAreaOnKeyPress(event)}
                                      disabled={isMessageInputBlockDisabled}
                                      style={{height: inputHeight}}>
                                {messageText}
                            </textarea>
                        </div>
                        <svg width="20" height="20">
                            <rect width="100%" height="100%" fill="#fff" />
                            <circle cx="100%" cy="0" r="100%" fill="#efefef" />
                        </svg>
                    </div>
                    <IconButton className="rounded-pill m-3"
                                sx={{color: "#025EA1", backgroundColor: "#fff", height: 48, width: 48, ":disabled": {backgroundColor: "#e0e0e0"}}}
                                onClick={handleSendButtonOnClick} disabled={!messageText}>
                        <i className="fa-regular fa-paper-plane" style={{height: 30, width: 30}}></i>
                    </IconButton>
                </div>
            </div>
        </>
    );
};