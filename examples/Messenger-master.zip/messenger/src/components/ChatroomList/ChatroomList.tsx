 import React, {useContext, useEffect, useState} from "react";
import {ChatroomCard} from "@src/components/ChatroomList/ChatroomCard/ChatroomCard";
import {Divider, IconButton, InputBase} from '@mui/material';
import {ChatContext} from "@src/ChatroomContext";
 import "./ChatroomList.css";
 import {IChatroom} from "@src/interfaces/IChatroom";


export const ChatroomList = () => {
    const {currentUser, chatrooms, setChatroom} = useContext(ChatContext);
    const [searchValue, setSearchValue] = useState('');

    function handleChatroomCardOnClick(chatroom: IChatroom) {
        setChatroom(chatroom);
        document.cookie = `chatroom_uuid=${chatroom.chatroom_uuid}; path=${location.href}; samesite=strict;`
    }

    return (
        <>
            <div className="chatroom-list">
                <div className="chatroom-list-header">
                    <div key="user-avatar"
                        className="chatroom-list-header-user-avatar">
                        {currentUser ? `${currentUser?.rus_surname?.toUpperCase()[0]}${currentUser?.rus_name?.toUpperCase()[0]}` : ""}
                    </div>
                    <div className="chatroom-list-header-user-info">
                        {currentUser ? `${currentUser?.rus_surname[0].toUpperCase() + currentUser?.rus_surname.slice(1).toLowerCase() } ${currentUser?.rus_name[0].toUpperCase()}.${currentUser?.rus_patronymic[0].toUpperCase()}.` : ""}
                    </div>
                </div>

                <div key="chatroom-search" className="vstack mx-2">
                    <div className="hstack border border-dark-subtle rounded-pill" style={{height: 40}}>
                        <InputBase className="ms-2"
                                   placeholder="Найти чат"
                                   onChange={event => setSearchValue(event.currentTarget.value)}
                                   disabled={chatrooms?.length === 0 || chatrooms === undefined} />
                        <Divider orientation="vertical"/>
                        <IconButton style={{height: 36, width: 36, margin: 2}} disabled={!searchValue}><i
                            className="fa-solid fa-magnifying-glass"></i></IconButton>
                    </div>
                </div>
                <div key="chatroom-card-list" className="chatroom-card-list">
                    {chatrooms ? chatrooms?.map((chatroom) => <ChatroomCard key={`chatroom_${chatroom.id}`}
                                                                                        chatroom={chatroom}
                                                                                        setChat={() => handleChatroomCardOnClick(chatroom)}/>)
                               : <></>
                    }
                </div>
                {/*<div key="spacer" className="border-top border-dark-subtle mx-2" style={{minHeight: 58}}></div>*/}
            </div>
        </>
    );
};