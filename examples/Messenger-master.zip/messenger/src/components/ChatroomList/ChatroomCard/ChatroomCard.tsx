import React, {MouseEventHandler} from "react";
import {IChatroom} from "@src/interfaces/IChatroom";

interface IProps {
    chatroom: IChatroom,
    setChat: MouseEventHandler<HTMLDivElement>,
}

export const ChatroomCard = (props: IProps) => {
    const {chatroom, setChat} = props;

    return (
        <>
            <div className="hstack gap-2 align-items-center ms-2"
                 style={{minHeight: 50, cursor: "pointer"}}
                 onClick={setChat}>
                <i className="fa-regular fa-comment" style={{height: 30}}></i>
                <div className="hstack h-100 w-100 border-bottom border-dark-subtle">
                    <div className="vstack">
                        <div>{chatroom?.chatroom_name}</div>
                        <div className="fst-italic ms-2" style={{fontSize: 14, color: "grey"}}>{"Your: Last message"}</div>
                    </div>
                    <div className="d-flex gap-1 align-items-start ms-auto mt-2 h-100">
                        {chatroom?.unread_messages ? <div className="d-flex justify-content-center align-items-center text-white rounded-pill fw-bold"
                             style={{height: 20, width: 20, padding: 2, backgroundColor: "#025EA1"}}>{chatroom?.unread_messages}</div> : <></>}
                        <div className="d-flex justify-content-center align-items-center rounded-pill" style={{height: 20, width: 20, backgroundColor: "rgba(206, 212, 218, 0.5)"}}>
                            <i className="fa-solid fa-thumbtack" style={{rotate: "45deg", color: "rgba(33, 37, 41, 0.25)"}}></i>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};