import React from 'react';
import {createRoot} from 'react-dom/client';
import {HashRouter, Route, Routes} from "react-router-dom";
import {Chat} from "@src/components/pages/Chat/Chat";
import "./AppStyle.css"
import "./image/fontawesome/all.js"

const App: React.FC = () => {
    document.oncontextmenu = () => false;

    return (
        <HashRouter>
            <Routes>
                <Route index element={<Chat />} />
            </Routes>
        </HashRouter>
    );
};

const rootElement = document.getElementById('root');
const root = createRoot(rootElement!);
root.render(<App/>);
