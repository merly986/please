import {getRequest} from "@src/controllers/MessengerRequest";
import {IResponse} from "@src/interfaces/IResponse";
import {IJson} from "@src/interfaces/IJson";
import {IUser} from "@src/interfaces/IUser";


export async function whoAmI(): Promise<IJson<IUser>> {
    const result: IResponse = await getRequest("who-am-i/");

    if (result.error === 0) {
        try {
            return  {result: await result.response.json(), error: 0};
        } catch (err) {
            console.log(err);
            return {result: undefined, error: err};
        }
    } else return {result: undefined, error: "Отсутствует связь с сервером"};
}