import {IResponse} from "@src/interfaces/IResponse";

const API_URL = `${location.origin}/messengerapi/v1/`;
// const API_URL = 'http://127.0.0.1:8000/v1/';
// const API_URL = 'http://127.0.0.1:8000/';

/**
 * Послать get запрос
 * @param path Путь к API
 */
async function getRequest(path: string): Promise<IResponse> {
    try {
        // const response: Response = await fetch(new URL(`${API_URL}${path}`));
        const response: Response = await fetch(`${API_URL}${path}`);

        if (response.ok) return {response: response, error: 0};
        else {
            console.log(`${response.status}: ${response.statusText}`);
            return {response: undefined, error: `${response.status}: ${response.statusText}`};
        }
    } catch (err) {
        console.log(err);
        return {response: undefined, error: err};
    }
}

/**
 * Послать post запрос
 * @param path Путь к API
 * @param json обьект для отправки
 */
async function postRequest(path: string, json: BodyInit): Promise<IResponse> {
    try {
        const response: Response = await fetch(new URL(`${API_URL}${path}`),
            {
                method: "POST",
                body: json,
                headers:{
                    "Content-Type":"application/json",
                }
            });

        if (response.ok) return {response: response, error: 0};
        else {
            console.log(`${response.status}: ${response.statusText}`);
            return {response: undefined, error: `${response.status}: ${response.statusText}`};
        }
    } catch (err) {
        console.log(err);
        return {response: undefined, error: err};
    }
}

export {
    getRequest,
    postRequest,
};