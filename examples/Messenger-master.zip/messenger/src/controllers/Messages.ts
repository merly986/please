import {IJson} from "@src/interfaces/IJson";
import {IMessage} from "@src/interfaces/IMessage";
import {IResponse} from "@src/interfaces/IResponse";
import {getRequest, postRequest} from "@src/controllers/MessengerRequest";


/**
 * Получить все сообщения из chatroom
 * @param chatroomUUID Идентификатор chatroom'а
 */
async function getMessages(chatroomUUID: string): Promise<IJson<IMessage[]>> {
    const result: IResponse = await getRequest(`messages/${chatroomUUID}/`);

    if (result?.error === 0) {
        try {
            return {result: await result.response.json(), error: 0};
        } catch (err) {
            console.log(err);
            return {result: undefined, error: err};
        }
    } else return {result: undefined, error: result?.error};
}

/**
 * Отправить сообжение в chatroom
 * @param message Сообщение
 */
async function sendMessage(message: IMessage) {
    let result: IResponse = undefined;
    try {
        const json = JSON.stringify(message);

        result = await postRequest("messages/", json);

        if (result?.error === 0) {
            return {result: await result.response.json(), error: 0};
        } else return {result, error: result?.error};
    } catch (err) {
        console.log(err);
        return {result, error: err};
    }
}

/**
 * Получить строку времени в формате "ДД.ММ.ГГГГ, ЧЧ:ММ:СС"
 * @param timestampString дата и время в виде стороки
 * @param type
 * @return {string}
 */
function timestampStringToFormatString(timestampString: string, type: string) {
    if (timestampString) {
        const date = new Date(Date.parse(timestampString));
        let format = {};
        switch (type) {
            case "date":
                format = {
                    day: 'numeric',
                    month: 'numeric',
                    year: 'numeric',
                    timeZone: 'Asia/Yekaterinburg'
                };
                return date.toLocaleDateString('ru-RU', format);

            case "time":
                format = {
                    hour: 'numeric',
                    minute: 'numeric',
                    second: 'numeric',
                    timeZone: 'Asia/Yekaterinburg'
                };
                return date.toLocaleTimeString('ru-RU', format);

            default:
                format = {
                    day: 'numeric',
                    month: 'numeric',
                    year: 'numeric',
                    hour: 'numeric',
                    minute: 'numeric',
                    second: 'numeric',
                    timeZone: 'Asia/Yekaterinburg'
                };
                return date.toLocaleDateString('ru-RU', format);
        }
    } else return '';
}

export {
    getMessages,
    sendMessage,
    timestampStringToFormatString
};