import {IResponse} from "@src/interfaces/IResponse";
import {getRequest, postRequest} from "@src/controllers/MessengerRequest";
import {IJson} from "@src/interfaces/IJson";
import {IChatroom} from "@src/interfaces/IChatroom";
import {IUser} from "@src/interfaces/IUser";

/**
 * Получить список chatroom'ов
 */
async function getChatrooms(): Promise<IJson<IChatroom[]>> {
    const result: IResponse = await getRequest("chatrooms/");

    if (result?.error === 0) {
        try {
            return  {result: await result.response.json(), error: 0};
        } catch (err) {
            console.log(err);
            return {result: undefined, error: err};
        }
    } else return {result: undefined, error: "Отсутствует связь с сервером"};
}

/**
 * Добавить пользователя в chatroom
 * @param chatroomUUID uuid chatroom'а
 * @param userID id пользователя
 * @param isModerator дать пользователю права модератора chatroom'а (default=False)
 */
async function addUserToChatroom(chatroomUUID: string, userID: number, isModerator?: boolean):Promise<IJson<IUser>> {
    const result: IResponse = await postRequest(`chatrooms/${chatroomUUID}/add-user/`, JSON.stringify({user_id: userID, is_moderator: isModerator}));

    if (result?.error === 0) {
        try {
            return {result: await result.response.json(), error: 0};
        } catch (err) {
            console.log(err);
            return {result: undefined, error: err};
        }
    } else return {result: undefined, error: result.error};
}

function getLastChatroomUUID() {
    let matches = document.cookie.match(new RegExp(
        "(?:^|; )chatroom_uuid=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
}

export {
    addUserToChatroom,
    getChatrooms,
    getLastChatroomUUID,
};