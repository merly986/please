import {IResponse} from "@src/interfaces/IResponse";
import {getRequest} from "@src/controllers/MessengerRequest";
import {IJson} from "@src/interfaces/IJson";
import {IUser} from "@src/interfaces/IUser";

export async function getUsers(chatroomUUID: string): Promise<IJson<IUser[]>> {
    const result: IResponse = await getRequest(`users/${chatroomUUID}/`);

    if (result?.error === 0) {
        try {
            return  {result: await result.response.json(), error: 0};
        } catch (err) {
            console.log(err);
            return {result: undefined, error: err};
        }
    } else return {result: undefined, error: result?.error};
}