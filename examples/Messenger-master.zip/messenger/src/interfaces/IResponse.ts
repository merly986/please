/**
 * Модель ответа сервера
 */
export interface IResponse {
    error: number | string,
    response: Response,
}