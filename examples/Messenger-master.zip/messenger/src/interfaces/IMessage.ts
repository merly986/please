import {IUser} from "@src/interfaces/IUser";

/**
 * Модель сообщения
 */
export interface IMessage {
    chatroom: number,
    message_text: string,
    author_info?: IUser,
    created_by?: number,
    id?: number,
    post_created?: string,
    post_edited?: null,
    it_answer_to_message_of_user?: number,
    it_answer_to_message_of_user_info?: IMessage,
    it_answer_to_user?: number,
    it_answer_to_user_info?: IUser,
}