/**
 * Модель json овета сервера
 */
export interface IJson<T> {
    result: T,
    error: number | string,
}
