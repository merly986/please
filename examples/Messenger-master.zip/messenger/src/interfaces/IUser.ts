/**
 * Модель пользователя
 */
export interface IUser {
    div_no: number
    full_name: string,
    rus_id: number,
    rus_name: string,
    rus_patronymic: string,
    rus_surname: string,
}