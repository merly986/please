import {IUser} from "@src/interfaces/IUser";

/**
 * Модель Chatroom'а
 */
export interface IChatroom {
    creator_info: IUser,
    created_from: string,
    chatroom_created_by: number,
    chatroom_name: string,
    chatroom_users: IUser[],
    chatroom_uuid: string,
    id: number,
    is_blocked: boolean,
    unread_messages: number,
    url_to_document: string,
    user_self_add: boolean,
}