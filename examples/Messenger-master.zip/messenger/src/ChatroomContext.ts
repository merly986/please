import {createContext, Dispatch, SetStateAction} from "react";
import {IUser} from "@src/interfaces/IUser";
import {IChatroom} from "@src/interfaces/IChatroom";
import {IMessage} from "@src/interfaces/IMessage";

interface IChatContext {
    currentUser: IUser,
    chatroom: IChatroom,
    chatrooms: IChatroom[],
    messages: IMessage[],
    users: IUser[],
    updateAll: Function,
    setChatroom: Dispatch<SetStateAction<IChatroom>>,
    setMessages: Dispatch<SetStateAction<IMessage[]>>,
}
export const ChatContext = createContext<IChatContext | null>(null);